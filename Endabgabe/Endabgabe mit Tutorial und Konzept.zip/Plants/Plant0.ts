namespace FieldSimulator {
    export class Plant0 extends Plant {
        name: string = "Plant0";
        waterDrainage: number = 0;
        fertilizerDemand: number = 0;
        pestsProbability: number = 0;
        growthSpeed: number = 0;
        
    }
}