namespace FieldSimulator {
    export class Plant5 extends Plant {
        name: string = "Plant5";
        waterDrainage: number = 1;
        fertilizerDemand: number = 1;
        pestsProbability: number = 3;
        growthSpeed: number = 1;
        
    }
}